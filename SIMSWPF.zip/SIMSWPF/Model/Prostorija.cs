﻿public class Prostorija
{

    private long idprostorije;

    public long Idprostorije { get => idprostorije; set => idprostorije = value; }

    public Prostorija(long idprostorije)
    {
        this.idprostorije = idprostorije;
    }

    public Prostorija()
    {
    }
}

