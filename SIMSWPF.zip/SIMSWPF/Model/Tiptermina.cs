// File:    Tiptermina.cs
// Author:  Korisnik
// Created: Tuesday, April 5, 2022 3:16:49 PM
// Purpose: Definition of Enum Tiptermina

using System;

public enum Tiptermina
{
   pregled,
   operacija
}